# -*- coding: utf-8 -*-
"""
Created on Wed Sep 28 11:42:52 2016

@author: n9606106
"""
from pandas.io.parsers import read_csv
import csv
import elasticsearch
import string
import nltk
import networkx as nx
import numpy as np


from nltk import word_tokenize
from nltk.stem import PorterStemmer
from nltk.corpus import stopwords
from nltk.stem.wordnet import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
#from sklearn.datasets import fetch_20newsgroups
from time import time
import statistics
from sklearn.feature_extraction.text import CountVectorizer
import itertools

'''
from data import Dataset
from scipy.cluster.hierarchy import fcluster 
from scipy.cluster.hierarchy import linkage
from scipy.cluster.hierarchy import dendrogram
from matplotlib import pyplot as plt
from sklearn.cluster import KMeans

from collections import defaultdict
from collections import Counter
'''


class Doc:
    def __init__(self,identity):
        self.visited = None
        self.CID = 0
        self.info = None
        self.identity = identity
        
class DocLoad:
    def __init__(self, idx, dtype):        
        self.INDEX_NAME = idx
        self.TYPE_NAME = dtype
        self.bulk_data=[]
    
    def clearData(self,docSet):
        for edoc in docSet:
            edoc.visited= None
        
    def loadData(self):
        
        articles=[]
        actual =[]       
        f = open('wiki_all.txt', encoding='latin-1') #name of the input data text file : class-content
        
        for line in iter(f):
            fields = line.split('\t')
            actual.append(fields[0])
            articles.append(fields[1])   
        return articles,actual
       
    def prePros(text, stem=True, lem=True):
        """ Tokenize text and stem words removing punctuation """
        exclude = set(string.punctuation)
        text = ''.join(ch for ch in text if ch not in exclude)#delete punctuation
        tokens = word_tokenize(text) # token the words
     
        if stem:
            stemmer = PorterStemmer()
            tokens = [stemmer.stem(t) for t in tokens] # stemming words which have same meaning
    
        if lem:
            lemmer = WordNetLemmatizer()
            tokens =[lemmer.lemmatize(t) for t in tokens]
        return tokens
        
    def qLengthCalculation(self,articles,k,rhoTheshold,shortCorpusTreshold):
        vectorizer = TfidfVectorizer(tokenizer=DocLoad.prePros,
                                     analyzer = 'word',
                                     stop_words=stopwords.words('english'), #stop word removal
                                     lowercase=True, use_idf=True, smooth_idf=False, norm=None) #idf=> smooth_idf=False, norm=None, #tf => use_idf=False
                                     
        tfidf_matrix = vectorizer.fit_transform(articles)
       
        p1=tfidf_matrix.shape[1]
        print("Number of terms in tfidf matrix "+str(p1))
        maxminterms=[]
        for doc in tfidf_matrix.todense():        
               # dlength=len([score for score in doc.tolist()[0] if score > 0 in doc.tolist()[0]])
                maxminterms.append(len([score for score in doc.tolist()[0] if score > 0 in doc.tolist()[0]]))
        p2=max(maxminterms)
        #print("Maximum number of terms "+str(p2))   
        rho=p2/p1
        print("Rho ratio "+str(rho)) 
        '''
        print("Mean document length distribution"+str(statistics.mean(maxminterms)))
        print("Mode document length distribution"+str(statistics.mode(maxminterms)))
        print("Median document length distribution"+str(statistics.median(maxminterms)))
        print("Standard Deviation in document length distribution"+str(statistics.stdev(maxminterms)))
        print("Varaince in document length distribution"+str(statistics.variance(maxminterms)))
        '''
        qlength=0
        qratio=0
        
        if len(articles) > shortCorpusTreshold:
            qratio=round((k*rhoTheshold),2)        
        else:
            if rho > rhoTheshold :
                qlength=(k*p2)/100
            else:               
                qlength=(k*p2)/(2*100)
        
        return int(round(qlength,0)),float(round(qratio,2))
    
    def vsmCalculation(self,articles,qlength=10,qratio=0) :
        
        vectorizer = TfidfVectorizer(tokenizer=DocLoad.prePros,
                                     analyzer = 'word',
                                     stop_words=stopwords.words('english'), #stop word removal
                                     lowercase=True, use_idf=True, smooth_idf=False, norm=None) #idf=> smooth_idf=False, norm=None, #tf => use_idf=False
                                     
        tfidf_matrix = vectorizer.fit_transform(articles)
        feature_names = vectorizer.get_feature_names() 
        print("Number of terms in tfidf matrix"+str(tfidf_matrix.shape[1]))
        with open("tfidf_query.csv", "w", newline='') as file:  # write phrases that have high tfidf|tf|idf value to csv
            writer = csv.writer(file, delimiter=",")
            writer.writerow(["DocId", "Phrases"])
            
            #maxminterms=[]
            doc_id = 0
            for doc in tfidf_matrix.todense(): 
                '''
                liscore=[]
                for score in doc.tolist()[0]: 
                    liscore.append(score)
                avgscore=sum(liscore)/tfidf_matrix[doc_id].getnnz()      #terms with weight more than average weight          
                #avgscore= avgscore/4
                '''
                dlength=len([score for score in doc.tolist()[0] if score > 0 in doc.tolist()[0]])
                #maxminterms.append(len([score for score in doc.tolist()[0] if score > 0 in doc.tolist()[0]]))
                name = []
                word_id = 0
                weight = []
               
                for score in doc.tolist()[0]:                
                    if score > 0 : #score > avgscore for full length
                                            
                        word = feature_names[word_id]                        
                        name.append(word)  
                        weight.append(score)
                    word_id +=1 
               
                '''
                terms=' '.join(name)    
                maxminterms.append(len(terms.split()))
                writer.writerow([doc_id, terms])
                doc_id +=1
                '''
                if qratio == 0:
                    ql = qlength
                else:                    
                    ql= int(round((qratio*dlength),0))
                
                words=[]
                
                for term in sorted(zip(weight, name), reverse=True)[:10]:   #[:10] is to select max weight 10 terms             
                      words.append(term[1]) 
                terms=' '.join(words)                  
                writer.writerow([doc_id, terms])
               
                doc_id +=1
                
            #print("static Query length"+str(max(maxminterms))/)
            #print("Maximum number of terms"+str(max(maxminterms)))
            '''
            print("Minimum number of terms"+str(min(maxminterms)))
            print("Average number of terms"+ str(sum(maxminterms)/len(tfidf_matrix.todense())))
            '''
        return tfidf_matrix
    def writeIDF(self,articles,actual) :
        #nltk.data.path.append("/home/9606106/nltk_data")
        
        vectorizer = TfidfVectorizer(tokenizer=DocLoad.prePros,
                                     analyzer = 'word',
                                     stop_words=stopwords.words('english'), #stop word removal
                                     lowercase=True, use_idf=True, smooth_idf=False, norm=None)
                   
       
        idf_matrix = vectorizer.fit_transform(articles)
        idf_vector=vectorizer.idf_  

        
        with open("idfmatrix_test.csv", "w", newline='') as file:  # write 3 phrases that have high tfidf value to csv
            writer = csv.writer(file, delimiter=",")
            #writer.writerow(["DocId", "Phrase1", "Phrase2", "Phrase3"])
            
            doc_id = 0
            for doc in idf_matrix.toarray():
                liscore=[]
                sc=0
                
                for score in doc: 
                    if score > 0 :
                        liscore.append(idf_vector[sc])
                    sc += 1
                '''    
                if len(liscore) >0 :
                    allidf=str(sum(liscore)/len(liscore))
                '''
                #finalstring=' '.join(allidf)
                #writer.writerow([finalstring])
                 
                writer.writerow(liscore)  
                doc_id +=1
        
        return idf_matrix 
    
    def calculateAvgIDF(self,actual) :
        
        seavg=[]
        with open("avgidfmatrix_test.csv", "w", newline='') as file:
            writer = csv.writer(file, delimiter=",")
            with open('idfmatrix_test.csv', 'r') as c:             
                read= csv.reader(c) 
                d=0
                for k in read:                    
                    if k is not None: 
                        avgidf=0.0
                        k = list(map(float, k))
                        if len(k) > 0:
                            avgidf=sum(k)/len(k)
                           
                        seavg.append(avgidf)
                        writer.writerow([avgidf , str(actual[d])]) 
                        d += 1
        print("Average IDF"+str(statistics.mean(seavg)))
        print("Median IDF"+str(statistics.median(seavg)))
        print("Standard Deviation IDF"+str(statistics.stdev(seavg)))
        print("Vaiance of IDF"+str(statistics.variance(seavg)))
        return (statistics.median(seavg)+statistics.stdev(seavg))
    
    
    def highIDFNoise(self,avgidf) :
        realNoise=[]
        with open('avgidfmatrix_test.csv', 'r') as c:   
             read= csv.reader(c) 
             d=0
             for k in read:                    
                if k is not None: 
                    m = float(k[0])                
                    if m > avgidf:
                        realNoise.append(d)
                d += 1
                        
        return realNoise
   
    
    def createIndexing(self, idx, docload):  # indexing documents
        large_data =[]       
        large_data,labels = docload.loadData()
        
        
        for k,row in enumerate(large_data):        
            data_dict = {}               
            data_dict["content"] = row           
            op_dict = {
                "index": {
                	"_index": self.INDEX_NAME, 
                	"_type": self.TYPE_NAME, 
                	"_id": k
                }            
            }
            
            self.bulk_data.append(op_dict)
            self.bulk_data.append(data_dict)   
       
                
        es = docload.elasticsearchConnection()
        
        if es.indices.exists(idx):                    
            res = es.indices.delete(index = idx, ignore=[400, 404])
                   
        
        # since we are running locally, use one shard and no replicas
        request_body = {
            "settings" : {
                "number_of_shards": 1,
                "number_of_replicas": 0
            }
        }
        
        '''
        request_body = {
             "settings": {
	            "number_of_shards": 1,
               "number_of_replicas": 0,
	            "analysis": {
	                "filter": {
	                    "my_shingle_filter": {
	                        "type":     "shingle",
	                        "min_shingle_size": 2, 
	                        "max_shingle_size": 5, 
	                        "output_unigrams":  False  
	                    }
	                },
	                "analyzer": {
	                    "my_shingle_analyzer": {
	                        "type":             "custom",
	                        "tokenizer":        "standard",
	                        "filter": [
	                            "lowercase",
	                            "my_shingle_filter" 
	                        ]
	                    }
	                }
	            }
            },
            "mappings": {
                self.TYPE_NAME : {
                  "properties": { 
                    "content": { 
                    "type": "string",
                    "fields": {
                      "shingles": {
                        "type": "string",
                        "analyzer": "my_shingle_analyzer"
          }}}} } }                 
        }
        '''                 
        #creating index
        res = es.indices.create(index = self.INDEX_NAME, body = request_body, ignore=400)
       
        
        # bulk index the data        
        res = es.bulk(index = self.INDEX_NAME, body = self.bulk_data, request_timeout=99999, refresh = True)         
        
       
        
    def elasticsearchConnection(self):  # establish elastic search connection
        es = elasticsearch.Elasticsearch(timeout=30000)        
        return es
           
    
    # query formation from terms in the tfidf_query.csv file
    def queryFormation(self,Q):     # create query vsm terms

         query=""
         
         with open('tfidf_query.csv', 'r') as c:        
            next(c)
            read= csv.reader(c)         
            for k in read:
                if k is not None:
                    if int(k[0]) == Q :                        
                                query = str(k[1])
         
         
         return query.strip()           
     
    '''  
         
    def queryFormation(self,Q):     # create query from high tfidf terms
         query=""
         with open('tfidf_query.csv', 'r') as c:        
            next(c)
            read= csv.reader(c)         
            for k in read:
                if k is not None:
                    if int(k[0]) == Q :
                        for i in range(1,4):
                            if len(k) >= i +1 :
                                query += str(k[i]+" ")
         
         return query.strip()           
    '''
    def WriteSEQueryResults(self, docSet, idx, docload):   # quering  through elastic search      
        s=([len(docSet), len(docSet)])
        mat=np.zeros(s,dtype=int)

        arr=[]                 
        with open("query_results.csv", "w", newline='') as file:  # write search results to csv
                writer = csv.writer(file, delimiter=",")
                writer.writerow(["DocId", "Docset"])
                doc_id = 0
                for Q in  docSet:            
                    results=[]
                    docls=[]
                   
                    
                    s=""     
                    es = docload.elasticsearchConnection()
                    query = docload.queryFormation(int(Q.identity))                                   
                   
                  
                    #res = es.search(index=self.INDEX_NAME, doc_type=self.TYPE_NAME, body={ 'size': 30,  'query': {'match': {'_all':{ 'query': query, 'minimum_should_match': "30%" } } }}) #search query
                    res = es.search(index=self.INDEX_NAME, doc_type=self.TYPE_NAME, body={ 'query': {'match': {'_all':{ 'query': query, 'minimum_should_match': "30%" } } }}) #search query    
                    for doc in res['hits']['hits']:               
                        results.append((int(doc['_id']),(doc['_score'])))                       
                        docls.append(doc['_id'])
                        mat[(doc_id),(int(doc['_id']))]=1
                    arr.append(docls)                                         
                    s = ','.join(map(str,results))                   
                    writer.writerow([Q.identity, s])                    
                    doc_id +=1
        return arr,mat
    


    
    def searchEngineQuery(self, Q, df, start=0, stop=20):   # read query results of elastic search 
        
        results=[]
        text=""
        '''
        c.seek(0)
        next(c)
        read= csv.reader(c)
        for k in read:
                if k is not None:
                    if int(k[0]) == Q.identity :
                        text=k[1]
        results=text.split(",")              
        '''
        
        if any(df['DocId'] == Q.identity):
                text=df['Docset'].iloc[Q.identity]
        results=str(text).split(",") 
        return results[start:stop]   
        
     
class GraphBuilding:
    def __init__(self, docSet, idx, d):
        self.docSet = docSet        
        self.idx=idx
        self.docload =d
        self.snnG=nx.Graph()        # initialize the snn graph
        self.hubG=nx.Graph()        # initialize the hub graph
      
        
    def SNNGraph(self):   # building SNN Graph and Hub Graph
        
        inconsistentDocs1=[] # inconsistent docs that are really noise in terms of DBSCAN   
        #inconsistentDocs2=[]
        hub=[]
        i=0
        HubDict={}
        #strongHub=[]        # hubs that have more strong interconnection
        docId=[]
        
        df=read_csv('query_results.csv')    
        #df.replace(['nan', 'None'], '')
        t=0.0
        
       
        for j in self.docSet:
            docId.append(j.identity)
                 
        
        
        for op in range(0, len(self.docSet)):
            
            doc=self.docSet[op]
            dictQryResults=[]
            listQryResults=[]
            if doc.visited is None:
                doc.visited = "visited"
          
            rows=self.docload.searchEngineQuery(doc,df) #search engine Query
           
            
            for j in rows[::2]: 
                if j and j != "nan" :                    
                    dictQryResults.append(int(str(j).strip(" () "))) 
            '''
            for n in dictQryResults:                    
                    for j in self.docSet:
                        if j.identity == n :
                            listQryResults.append(j)         # preparing doc query results  
            '''
            t8 = time() 
            listQryResults=[self.docSet[n] for n in dictQryResults if n in docId]
            t11 = time()
            t1=0.0
           
            for k in [x for x in listQryResults if x != doc]:
       
                    commonDocs={}
                    
                    dictSubQryResults=[]      
                    listSubQryResults=[]
                    #if k.visited is None:
                        
                    subrows=self.docload.searchEngineQuery(k,df) #search engine Query
                        
                        
                    for m in subrows[::2]:                            
                        if m and m != "nan" :                                
                            dictSubQryResults.append(int(str(m).strip(" () "))) 
                        
                        
                        '''
                        for n in dictSubQryResults:
                                for j in self.docSet:
                                    if j.identity == n :
                                        listSubQryResults.append(j)         # preparing doc query results
                        '''
                    t9 = time()  
                    listSubQryResults=[self.docSet[n] for n in dictSubQryResults if n in docId]
                    t10 = time()
                        
                          
                    if doc in listSubQryResults:
                        commonDocs=set(dictQryResults).intersection(set(dictSubQryResults))      # calculate SNN                      
                            
                        if len(commonDocs) > 0:
                            #print(len(commonDocs))
                            self.snnG.add_edge(doc,k,weight=len(commonDocs))                  
                            if list(commonDocs) not in hub:
                                if len(hub) < i+1:
                                    hub.append([]) 
                                hub[i].extend(list(commonDocs))                                                         #create hubs => start from 0                                    
                                self.hubG.add_edge(doc,(i))                                                             #add hubs to hub graph
                                HubDict[i]=0
                                i=i+1
                        
                    t1 += (t10-t9)
           
          
            
            #t += t1
        t +=(t11-t8)
       
           
        for d in self.docSet:            
            if d not in self.snnG.nodes():
                inconsistentDocs1.append(d)
        
        print("tot file reading time %.2fs" %(t))
        
        
        
        return inconsistentDocs1,HubDict,hub
    
    def matricGraph(self,mat):   # building SNN Graph and Hub Graph   
        b=list((i,j) for ((i,_),(j,_)) in itertools.combinations(enumerate(mat), 2))
        outlierScoreStat=[]
        k=0
        for iik in list(itertools.combinations(mat, 2)):
            #print(b[k],b[k][0],b[k][1])
            ln=np.count_nonzero(np.bitwise_and(iik[0],iik[1]))
            if ln > 0:
                self.snnG.add_edge(b[k][0],b[k][1],weight=ln)    
            k += 1
            
        d=self.snnG.degree()
        with open("Degree.csv", "w", newline='') as file:  # write search results to csv
                writer = csv.writer(file, delimiter=",")
                writer.writerow(["DocId", "Degree"])  
                for m, v in d.items():
                    writer.writerow([m, v]) 
                    outlierScoreStat.append(v)
                    
                for i in range(0,len(mat)):
                    if i not in d.keys():
                        writer.writerow([i, 0]) 
                        outlierScoreStat.append(0)
        return outlierScoreStat
    
    def OutlierDetemination(self,threshold):
        
        results=[]
      
        with open('Degree.csv', 'r') as c:        
            next(c)
            read= csv.reader(c)
            for k in read:
                    if k is not None:
                        if float(k[1]) < threshold:
                        #if float(k[1]) < 0.2 and int(k[0]) in inconsistentDocs1 :
                            results.append(int(k[0]))
        
        return results
                        
    def regionQuery(self,node, minWeight):          #neighbourhodd search
        neighbours=[]
        results=[]
        results=self.snnG.neighbors(node)
        for nd in results:
            if self.snnG[node][nd]['weight'] >= minWeight:               # take neighbours having more than or equal minWeight 
                neighbours.append(nd)
        return neighbours
        
    def findClusterHubs(self):  #take all hubs  
        dnInHubNet=[]       
        for node in self.hubG.nodes():
            if isinstance(node,Doc):                         
                dnInHubNet.append(node)                       
        return dnInHubNet
        
                  
    def updateClusterHubs(self, hubdict):          
        dnInHubNet = self.findClusterHubs()      
        for doc in dnInHubNet:            
            hubs=self.hubG.neighbors(doc)    
            for k in [h1 for h in hubs for h1,v in hubdict.items() if h1 == h]:     # update document cluster id to hubs in hubdict
                hubdict[k] = doc.CID
                       
            
        return hubdict
    
 


   
    
