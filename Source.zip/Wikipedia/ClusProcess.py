# -*- coding: utf-8 -*-
"""
Created on Tue Nov  8 17:01:02 2016

@author: n9606106
"""
from collections import defaultdict
from time import time
from pandas.io.parsers import read_csv
import statistics
import csv
''''
from collections import Counter
import numpy as np

from scipy.cluster.hierarchy import fcluster 
from scipy.cluster.hierarchy import linkage
from scipy.cluster.hierarchy import dendrogram
from matplotlib import pyplot as plt
from sklearn.cluster import KMeans
from sklearn import mixture
from sklearn.cluster import DBSCAN
from scipy.spatial import distance
'''

class ClusPhase1:
    
    CID = 0 #cluster id
    inconsistentDocs2=[]
    
    def __init__(self, docSet, MinWeight, MinDocs, d, g):
        self.docSet = docSet
        self.MinWeight = MinWeight
        self.MinDocs = MinDocs        
        self.docload =d
        self.graphbuilding = g
      
       
        
    def DocDenClus(self):        
          removeinconsistentDocs=[]
          inconDocs=[]
          for Q in self.docSet:          
            
            NeighbourDocs=[] # neighbourdocs ids
                
            if Q.visited is None:
                Q.visited = "visited"  
                #print(Q.identity)                             
                
                NeighbourDocs = self.graphbuilding.regionQuery(Q, self.MinWeight) #search region of SNN for neighbous                
               
                if len(NeighbourDocs) < self.MinDocs:    # noise docs within SNN graph                       
                        #Q.info = "NOT Relevant"   
                        inconDocs.append(Q)
                                                                       
                else:                              # Assign to cluster                                            
                    self.CID = self.CID + 1                                                                                  
                    self.exapandClsuter(Q, NeighbourDocs)           
          
          
          for icdoc in inconDocs:
              if icdoc.CID != 0:
                  removeinconsistentDocs.append(icdoc)
                  
          
          self.inconsistentDocs2=[item for item in inconDocs if item not in removeinconsistentDocs]              
          self.pureClusters=[item for item in self.docSet if item not in self.inconsistentDocs2]
        
          return self.inconsistentDocs2, self.pureClusters

    def exapandClsuter(self, P, NeighbourDocs):                            
        
        P.CID=self.CID          
        for PP in NeighbourDocs: 
       
            NeighbourDocsS=[]
            
            if PP.visited is None:                
                PP.visited = "visited"  
                
                NeighbourDocsS = self.graphbuilding.regionQuery(PP, self.MinWeight) # Neighbour's Neighbour Docs                  
                
                if len(NeighbourDocsS) >= self.MinDocs:                    
                    f_in =set(NeighbourDocs)
                    s_in=set(NeighbourDocsS)
                    add_in=s_in - f_in
                    for i in list(add_in):  # join initial and current neighbour docs
                        NeighbourDocs.append(i)
                                
            if PP.CID ==0 :
                PP.CID= self.CID
                
                
class ClusPhase2:
    
    def __init__(self, d):            
        self.docload =d
        
        
    def HubClosenessCal(self, IncosistentDocs, hub):
                
        hubClosenessScore = defaultdict(lambda: defaultdict(lambda: 0))
        df=read_csv('query_results.csv')   
        avgHub=[]           
        for doc in IncosistentDocs:           
            dictQryResults={}
            keys=[]
            values=[]
                 
            rows=self.docload.searchEngineQuery(doc,df) #search engine Query
            
            for i in rows[::2]:
                if i and i != "nan" :  
                    keys.append(int(str(i).strip(" () ")))    
                          
            for i in rows[1::2]:
                if i and i != "nan" :  
                    values.append(float(str(i).strip(" () ")))
                       
            for n in range(0,len(keys)):                
                dictQryResults[keys[n]]=values[n]           # prepare relevancy scoreand search results of a query
            
            for i in range(0,len(hub)) :
                sscore=0.0
                sscore = sum([v for k,v in dictQryResults.items() if k in hub[i]])/len(hub[i]) 
                hubClosenessScore[doc.identity][i]=sscore
                if sscore >0 :
                    avgHub.append(sscore)
        print("average"+str(statistics.mean(avgHub)))
        print("median"+str(statistics.median(avgHub)))
        print("stdv"+str(statistics.stdev(avgHub)))
        print("variance"+str(statistics.variance(avgHub)))
        return hubClosenessScore, round(statistics.mean(avgHub),3)
        
    def HubBasedClustering(self, IncosistentDocs1,InconsistentDocs2, Hubs, HubDict):
       
        outlier=[]
        IncosistentDocs1.extend(InconsistentDocs2)   # combine both type of inconsistent documents
       
        t14= time()
        hubClosenessScore,cut = self.HubClosenessCal(IncosistentDocs1, Hubs)
        print(cut)
        t15=time()
        print("time hub score cal %.2fs" %(t15-t14))
        t16= time()
        for indoc in IncosistentDocs1:  
            (key, value) = max(hubClosenessScore[indoc.identity].items(), key=lambda a: a[1]) 
            if value > 0 :
                indoc.CID =[v for k,v in HubDict.items() if k == key][0]  # assign to cluster of a hub which contain maximum relevancy
                if ([v for k,v in HubDict.items() if k == key][0] == 0) :
                    outlier.append(indoc.identity)
                    
            else:
                    outlier.append(indoc.identity)
                    
        t17= time()
        print("time hub based ccluster assignment %.2fs" %(t17-t16))
        
        return outlier
    
                  
            
                    

    
    def clusterSet(self,docSet):
        maxdocid=0
        cluster=[]
        for doc in docSet:
            if doc.CID>maxdocid:
                maxdocid=doc.CID
        
        for d in docSet:
             while len(cluster) <=d.CID:
                cluster.append([]) 
             
             cluster[d.CID].append(d)
        return cluster
    
class Outliers:
    # assign outlier score
    def __init__(self, d):            
        self.docload =d
        
   
    def CalOutlierScore(self, docSet, realNoise):
        df=read_csv('query_results.csv') 
        outlierScoreStat=[]
        with open("outlierScores.csv", "w", newline='') as file:  # write 3 phrases that have high tfidf value to csv
            writer = csv.writer(file, delimiter=",")  
           
            
            for dk in docSet:   #for dk in docSet: #for s in realNoise: 
                #dk=docSet[s]
                dictQryResultsD=[]
                dictQryResultsS=[]
                avgOutlierScore=0.0
                rows=self.docload.searchEngineQuery(dk,df) #search engine Query                      
                for i in rows[::2]:
                    if i and i != "nan" :  
                        dictQryResultsD.append(int(str(i).strip(" () ")))       
                for j in rows[1::2]: 
                    if j and j != "nan" :                    
                        dictQryResultsS.append(float(str(j).strip(" () ")))
                if dk.identity in dictQryResultsD:
                    ind=dictQryResultsD.index(dk.identity)
                    del dictQryResultsS[ind]
                '''
                if len(dictQryResultsS) > 0:                    
                    avgOutlierScore=(1/(sum(dictQryResultsS)/len(dictQryResultsS)))
                '''
                
                
                if len(dictQryResultsS) > 1 and statistics.stdev(dictQryResultsS) > 0:                                       
                    avgOutlierScore=(1/statistics.stdev(dictQryResultsS))
                elif len(dictQryResultsS) == 1:
                    avgOutlierScore=1/dictQryResultsS[0]
               
                writer.writerow([dk.identity, avgOutlierScore])
                outlierScoreStat.append(avgOutlierScore)
                
        
        return outlierScoreStat
    
    
    def CalOutlierScoreCal(self, docSet, realNoise):
        df=read_csv('query_results.csv') 
        outlierScoreStat=[]
        with open("outlierScores.csv", "w", newline='') as file:  # write 3 phrases that have high tfidf value to csv
            writer = csv.writer(file, delimiter=",")  
           
            
            for s in realNoise:    #for dk in docSet: #for s in realNoise: 
                dk=docSet[s]
                avgOutlierScore=[]
                score=0.0
                for s in docSet:
                    dictQryResultsD=[]
                    dictQryResultsS=[]
                   
                    rows=self.docload.searchEngineQuery(s,df) #search engine Query                      
                    for i in rows[::2]:
                        if i and i != "nan" :  
                            dictQryResultsD.append(int(str(i).strip(" () ")))       
                    for j in rows[1::2]: 
                        if j and j != "nan" :                    
                            dictQryResultsS.append(float(str(j).strip(" () ")))
                    if dk.identity in dictQryResultsD:
                        ind=dictQryResultsD.index(dk.identity)
                        avgOutlierScore.append(dictQryResultsS[ind])
                        
                if len(avgOutlierScore) > 0:
                    score=(1/statistics.mean(avgOutlierScore))
                writer.writerow([dk.identity, score])
                outlierScoreStat.append(score)
                
        
        return outlierScoreStat
                
    def OutlierDetemination(self,threshold):
        
        results=[]
      
        with open('outlierScores.csv', 'r') as c:        
            next(c)
            read= csv.reader(c)
            for k in read:
                    if k is not None:
                        if float(k[1]) > threshold:
                        #if float(k[1]) < 0.2 and int(k[0]) in inconsistentDocs1 :
                            results.append(int(k[0]))
        
        return results
    
    def OutlierDeteminationByCount(self,arr, realNoise, docSet):
        outlierScoreStat=[]
        with open("outlierScores.csv", "w", newline='') as file:  # write search results to csv
            writer = csv.writer(file, delimiter=",")
            writer.writerow(["DocId", "Docset"]) 
            outlierscore=0.0
            for s in realNoise:
                di=docSet[s]
                if sum(x.count(str(di.identity)) for x in arr) >0 :
                    outlierscore= 1/sum(x.count(str(di.identity)) for x in arr)
                    writer.writerow([di.identity, outlierscore]) 
                    outlierScoreStat.append(outlierscore)
            '''
            if sum(x.count(str(di.identity)) for x in arr) > 1000 :
                highProblist.append(di.identity)
            '''
            
        return outlierScoreStat
                             
   
               
        
                
        
        
        
            
        
            
            
            
            
        
                
            
            
                
        