# -*- coding: utf-8 -*-
"""
Created on Wed Nov  9 10:04:51 2016

@author: n9606106
"""
from DocLoad import Doc
from DocLoad import DocLoad
from DocLoad import GraphBuilding
from Measures import Measures
#import matplotlib.pyplot as plt
#from ClusterEval import nmi
#import networkx as nx
#from networkx_viewer import Viewer
#import matplotlib.pyplot as plt
#import sys
from time import time


if __name__ == "__main__":
    
    idx='wikidso'#20ngmini,#sed13,#sed14
    dtype='wikidso'#text20ng, #textS13, #textS14
    minWeight=3
    minDocs = 3
   
    docSet=[]    
    d = DocLoad(idx,dtype)
    articles,actual =d.loadData()
    for i in range(0,len(articles)): # testing with ascending order
        t=Doc(i)
        docSet.append(t) 
    print("Tot docs"+str(len(docSet)))   
    outclass=['arts','nature','Religion','Politics','Culture','Mathematics','Science and technology','Games','Geography','Health']
    gtPositives=[i for i,x in enumerate(actual) if x in outclass]
   
    #1st option-idf calculation and cutoff  
    idfmatrix=d.writeIDF(articles, actual)  
    t0= time()
    avgidf=d.calculateAvgIDF(actual)
    realNoise=d.highIDFNoise(avgidf)    
    print("time Difference%.2fs"%(time()-t0))
    #Output- analysis of output of option1
    
    outIn=[]
    for di in gtPositives:        
        if di in realNoise:            
            outIn.append(di)
            
    print("All Noise detected by 1st phase"+str(len(realNoise)))       
    print("Actual Outliers detected by 1st phase"+str(len(outIn)))
    
    
    #2nd option - SNN graph graph building(RDDC)
#    d.createIndexing(idx,d)         ########one time indexing is enough ########
#    arr,mat=d.WriteSEQueryResults(docSet,idx,d)   ########one time quering is enough ########
    

  
   
    #3rd option- SNN graph and hub graph building(RDDC)
    #3(a)
    t1= time()
    gb=GraphBuilding(docSet,idx,d)
    inconsistentDocs1,hubDict,hub=gb.SNNGraph()
    t2= time()
    outIn=[]
    for di in gtPositives:        
        if di in  inconsistentDocs1:            
            outIn.append(di)
            
    print("All Noise detected by 3rd phase(a)"+str(len(inconsistentDocs1)))       
    print("Actual Outliers detected by 3rd phase(a)"+str(len(outIn)))
    print("time Difference%.2fs"%((t2-t1)))
    pred=[]
    #print(gtPositives)
    for i in docSet:       
        if i.identity in inconsistentDocs1: #if i.identity in outlier: #if i.identity in rnoisenew: #if i.identity in inconsistentDocs1 #if i.identity in realnoise
            i.CID=0
        else:
            i.CID=1
        pred.append(i.CID)
    
    
  
    #5th option-Ovelapings
    rnoisenew=[]
    ta=time()
    for ig in realNoise:
        if ig not in gb.snnG:
               rnoisenew.append(ig)
    tb=time()
    
    outIn=[]
    for di in gtPositives:        
        if di in rnoisenew:            
            outIn.append(di)
            
    print("All Noise detected by final phase"+str(len(rnoisenew)))       
    print("Actual Outliers detected by final phase"+str(len(outIn)))   
  

    
    m=Measures()
    m.ROCcurve(actual,pred)
    
    
    
   
    
       
    