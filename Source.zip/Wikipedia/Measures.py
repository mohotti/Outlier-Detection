# -*- coding: utf-8 -*-
"""
Created on Tue Oct 11 11:37:12 2016

@author: n9606106
"""
'''
from matplotlib.pyplot import figure, show
import matplotlib.pyplot as plt
import numpy as np
'''
from sklearn.metrics import roc_curve, auc
#import matplotlib.pyplot as plt
#from scipy.optimize import brentq
#from scipy.interpolate import interp1d

class Measures:
    def nmi(self,doc2clust, doc2cat):
        import math
     
        dict1 = {}; dict2 = {}; num = 0.0; den_gs = 0.0; den_my = 0.0
        for l in doc2clust:
            if doc2clust[l][0] not in dict1:
                dict1[doc2clust[l][0]] = set([])
            dict1[doc2clust[l][0]].add(int(l))
     
        for l in doc2cat:
            if doc2cat[l][0] not in dict2:
                dict2[doc2cat[l][0]] = set([])
            dict2[doc2cat[l][0]].add(int(l))
     
        for event_my in dict1:
            den_gs += (float(len(dict1[event_my])) / float(len(doc2cat))) * math.log(float(len(dict1[event_my])) / float(len(doc2cat)), 2)
            eset = set()
            for entry in dict1[event_my]:
                for en in doc2cat[entry]:
                    eset.add(en)
            for event_gs in eset:
                num += (float(len(dict1[event_my] & dict2[event_gs]))/float(len(doc2cat))) * (math.log((float(len(doc2cat)) * float(len(dict1[event_my] & dict2[event_gs]))) / (float(len(dict1[event_my])) * float(len(dict2[event_gs]))), 2))
     
        for event_gs in dict2:
            den_my += float(len(dict2[event_gs])) / float(len(doc2cat)) * math.log(float(len(dict2[event_gs])) / float(len(doc2cat)), 2)
     
        nmi = num / (((-1)*den_gs + (-1)*den_my) / 2)
     
        return nmi
     
    def microf1(self,doc2clust, doc2cat):
        dict1 = {}; dict2 = {}; prec = 0.0; rec = 0.0
        for l in doc2clust:
            if doc2clust[l][0] not in dict1:
                dict1[doc2clust[l][0]] = set([])
            dict1[doc2clust[l][0]].add(int(l))
     
        for l in doc2cat:
            if doc2cat[l][0] not in dict2:
                dict2[doc2cat[l][0]] = set([])
            dict2[doc2cat[l][0]].add(int(l))
     
        for doc in doc2cat:
            prec += ( float(len(dict1[doc2clust[doc][0]] & dict2[doc2cat[doc][0]])) / float(len(dict1[doc2clust[doc][0]])) )
            rec  += ( float(len(dict1[doc2clust[doc][0]] & dict2[doc2cat[doc][0]])) / float(len(dict2[doc2cat[doc][0]])) )
     
        prec = prec / float(len(doc2cat))
        rec = rec / float(len(doc2cat))
        fmeasure = 2.0 * prec * rec / (prec + rec);
     
        return fmeasure
     
    def clust_distribution(self,clust2size):#cluster size distribution
        import math
        sizes = clust2size.values()
        cMean = float(sum(sizes)) / len(sizes)
        diff_mean_squared = [(float(x) - cMean)**2 for x in sizes]
        observations = len(sizes) # population distribution (i.e. all clusters) no need to subtract 1
        cStdDev = math.sqrt(sum(diff_mean_squared) / float(observations))
        cMax=max(sizes);cMin=min(sizes)
        return cMean,cStdDev,cMax,cMin
     
    def load(self,dclass,dclust):
        doc2clust = {}; doc2cat = {}; original_clust2size = {}
        doc2cat = dict((i,[doc]) for i,doc in enumerate(dclass));all_categories = set([c[0] for c in doc2cat.values()])
        doc2clust = dict((i,[doc]) for i,doc in enumerate(dclust));all_clusters = set([c[0] for c in doc2clust.values()])
     
        for cluster, docs in self.invert(doc2clust).items():
            original_clust2size[cluster] = len(docs)
        cMean,cStdDev,cMax,cMin=self.clust_distribution(original_clust2size)
     
        return (doc2clust, doc2cat, len(all_clusters), len(all_categories),cMean,cStdDev,cMax,cMin)
     
    def invert(self,key2values): # key -> list of values
        value2keys = {}
        for key, values in key2values.items():
            for value in values:
                if value in value2keys:
                    value2keys[value].append(key)
                else:
                    value2keys[value] = [key]
        return value2keys
     
    def f1_nmi(self,dclass,dclust):
        doc2clust, doc2cat, cluster_count,class_count,cMean,cStdDev,cMax,cMin = self.load(dclass,dclust)
        df1 = self.microf1(doc2clust, doc2cat)
        dnmi = self.nmi(doc2clust, doc2cat)
        return df1,dnmi,cluster_count,class_count,cMean,cStdDev,cMax,cMin
        
    
    def TruePositivesRate(self, outlierSize, gtPositives):   
        tpr=[]
        for i in range(0,len(outlierSize)):
            tempTpr=100*(len(set(outlierSize[i]).intersection(set(gtPositives)))/len(gtPositives))            
            tpr.append(tempTpr)
        return tpr
    
    def FalsePositivesRate(self,Csize, outlierSize, gtPositives):
       fpr=[]
       for i in range(0,len(outlierSize)):
            tempFpr=100*((len(set(outlierSize[i])-set(gtPositives)))/(Csize-len(gtPositives)))        
            fpr.append(tempFpr)            
       return fpr
    '''   
    def ROCcurve(self,outlierSize,gtPositives,Csize):
        tpr=self.TruePositivesRate(outlierSize, gtPositives)
        fpr=self.FalsePositivesRate(Csize, outlierSize, gtPositives)
        
        roc_auc = auc(fpr, tpr)
        plt.title('Receiver Operating Characteristic')
        plt.plot(fpr, tpr, 'b',
        label='AUC = %0.2f'% roc_auc)
        plt.legend(loc='lower right')
        plt.plot([0,1],[0,1],'r--')
        plt.xlim([-0.1,1.2])
        plt.ylim([-0.1,1.2])
        plt.ylabel('True Positive Rate')
        plt.xlabel('False Positive Rate')
        plt.show()
    '''

    def preProcess(self,actual, pred):
        act=[]; 
        '''           
        e='4191'    #outlier class1 'comp.graphics', 'interest' , '7276'
        y='1295'       #outlier class2  'talk.politics.mideast', 'grain, '6562''
        z='20141'        #outlier class3   'misc.forsale', 'ship', '19505'
        g='17609'       #'11199'
        q='11511'         #'387'
        a='15094'       # '17563'     
        b='9753'        # '5256'
        c='5328'       # '19395' 
        h='10677'        # '3478'
        f='8367'       # '18042'
        ee='7333'
        yy='12525'
        gg='11988'
        qq='14802'
        aa='1956'
        bb='111'
        cc='2907'
        hh='1030'
        ff='12837'
        zz='6743'
        dd='12389'
        ii='5761'
        jj='6852'
        kk='7691'
        ll='6636'
        mm='16154'
        nn='13796'
        oo='14109'
        '''
        #outclass=['6569', '11014', '11271', '12217', '19067', '9796', '11142', '12885', '6273', '4180', '6199', '13802', '11210', '13462', '10924', '1792', '17359', '1110', '19454', '2929', '16929', '6705', '125', '1482', '16380', '19428', '17481', '3893', '15148', '216', '965', '20598', '19377', '11005', '13564', '8367', '4592', '10852', '11036', '8029']
        #outclass=['4191', '1295', '20141', '17609', '11511', '15094', '9753', '5328', '10677', '8367', '7333', '12525', '11988', '14802', '1956', '111', '2907', '1030', '12837', '6743', '12389', '5761', '6852', '7691', '6636', '16154', '13796', '14109']
        #outclass=['3478','19505','11199']
        outclass=['arts','nature','Religion','Politics','Culture','Mathematics','Science and technology','Games','Geography','Health']
        for x in actual:
            #if x=='comp.graphics' or x == 'talk.politics.mideast' or x == 'misc.forsale':
            #if x == e or x == y or x == z or x==g or x== q or x ==a or x ==b or x ==c or x==h or x==f or x==ee or x==yy or x==zz or x==gg or x==qq or x==aa or x==bb or x==cc or x==hh or x==ff or x==ii or x=jj or x==kk or x==ll:
            if x in outclass:
                act.append(0)
            else:
                act.append(1)
       
        return act, pred
    
    def ROCcurve(self,actual,pred):
        #tpr=self.TruePositivesRate(outlierSize, gtPositives)
        #fpr=self.FalsePositivesRate(Csize, outlierSize, gtPositives)
    
        act, predictions=self.preProcess(actual,pred)
        fpr, tpr, thresholds = roc_curve(act, predictions)
        roc_auc = auc(fpr, tpr)
        print(roc_auc)
#        plt.title('Receiver Operating Characteristic')
#        plt.plot(fpr, tpr, 'b', label='AUC = %0.2f'% roc_auc)
#        plt.legend(loc='lower right')
#        plt.plot([0,1],[0,1],'r--')
#        plt.xlim([-0.1,1.2])
#        plt.ylim([-0.1,1.2])
#        plt.ylabel('True Positive Rate')
#        plt.xlabel('False Positive Rate')
#        plt.show()
	
        
        

